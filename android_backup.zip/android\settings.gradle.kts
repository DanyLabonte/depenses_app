pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

val localProps = java.util.Properties().apply {
    val f = file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val flutterSdkPath: String = (
        localProps.getProperty("flutter.sdk")
            ?: System.getenv("FLUTTER_HOME")
            ?: error("Flutter SDK introuvable. Ajoute flutter.sdk dans android/local.properties")
        )

includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
}

include(":app")
